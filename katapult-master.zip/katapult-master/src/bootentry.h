#ifndef __BOOTENTRY_H
#define __BOOTENTRY_H

int bootentry_check(void);

#endif // bootentry.h
