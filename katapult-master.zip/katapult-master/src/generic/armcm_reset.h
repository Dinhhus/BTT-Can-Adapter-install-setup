#ifndef __GENERIC_ARMCM_RESET_H
#define __GENERIC_ARMCM_RESET_H

void try_request_canboot(void);

#endif // armcm_reset.h
